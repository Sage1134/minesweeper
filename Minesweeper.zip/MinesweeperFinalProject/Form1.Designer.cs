﻿namespace MinesweeperFinalProject
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlTitle = new Panel();
            lblTitle = new Label();
            lblImpossible = new Label();
            lblExpert = new Label();
            lblIntermediate = new Label();
            lblEasy = new Label();
            lblBeginner = new Label();
            btnPlay = new Button();
            pbCanvasTitle = new PictureBox();
            pnlGamePage = new Panel();
            pbCanvasGameBoard = new PictureBox();
            pbCanvasBorder = new PictureBox();
            pnlTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbCanvasTitle).BeginInit();
            pnlGamePage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbCanvasGameBoard).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbCanvasBorder).BeginInit();
            SuspendLayout();
            // 
            // pnlTitle
            // 
            pnlTitle.BackColor = Color.FromArgb(125, 175, 175);
            pnlTitle.Controls.Add(lblTitle);
            pnlTitle.Controls.Add(lblImpossible);
            pnlTitle.Controls.Add(lblExpert);
            pnlTitle.Controls.Add(lblIntermediate);
            pnlTitle.Controls.Add(lblEasy);
            pnlTitle.Controls.Add(lblBeginner);
            pnlTitle.Controls.Add(btnPlay);
            pnlTitle.Controls.Add(pbCanvasTitle);
            pnlTitle.Location = new Point(0, 0);
            pnlTitle.Margin = new Padding(3, 4, 3, 4);
            pnlTitle.Name = "pnlTitle";
            pnlTitle.Size = new Size(199, 149);
            pnlTitle.TabIndex = 0;
            // 
            // lblTitle
            // 
            lblTitle.Anchor = AnchorStyles.None;
            lblTitle.Font = new Font("Arial Rounded MT Bold", 48F, FontStyle.Regular, GraphicsUnit.Point);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(-218, -138);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(646, 93);
            lblTitle.TabIndex = 2;
            lblTitle.Text = "MINESWEEPER";
            lblTitle.TextAlign = ContentAlignment.TopCenter;
            // 
            // lblImpossible
            // 
            lblImpossible.Anchor = AnchorStyles.None;
            lblImpossible.Font = new Font("Bahnschrift Condensed", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblImpossible.ForeColor = Color.FromArgb(80, 120, 120);
            lblImpossible.Location = new Point(277, -45);
            lblImpossible.Name = "lblImpossible";
            lblImpossible.Size = new Size(140, 33);
            lblImpossible.TabIndex = 12;
            lblImpossible.Tag = "4";
            lblImpossible.Text = "IMPOSSIBLE";
            lblImpossible.TextAlign = ContentAlignment.TopCenter;
            lblImpossible.Click += lblImpossible_Click;
            // 
            // lblExpert
            // 
            lblExpert.Anchor = AnchorStyles.None;
            lblExpert.Font = new Font("Bahnschrift Condensed", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblExpert.ForeColor = Color.FromArgb(80, 120, 120);
            lblExpert.Location = new Point(169, -45);
            lblExpert.Name = "lblExpert";
            lblExpert.Size = new Size(102, 33);
            lblExpert.TabIndex = 11;
            lblExpert.Tag = "3";
            lblExpert.Text = "EXPERT";
            lblExpert.TextAlign = ContentAlignment.TopCenter;
            lblExpert.Click += lblExpert_Click;
            // 
            // lblIntermediate
            // 
            lblIntermediate.Anchor = AnchorStyles.None;
            lblIntermediate.Font = new Font("Bahnschrift Condensed", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblIntermediate.ForeColor = Color.FromArgb(80, 120, 120);
            lblIntermediate.Location = new Point(2, -45);
            lblIntermediate.Name = "lblIntermediate";
            lblIntermediate.Size = new Size(161, 33);
            lblIntermediate.TabIndex = 10;
            lblIntermediate.Tag = "2";
            lblIntermediate.Text = "INTERMEDIATE";
            lblIntermediate.TextAlign = ContentAlignment.TopCenter;
            lblIntermediate.Click += lblIntermediate_Click;
            // 
            // lblEasy
            // 
            lblEasy.Anchor = AnchorStyles.None;
            lblEasy.Font = new Font("Bahnschrift Condensed", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblEasy.ForeColor = Color.FromArgb(80, 120, 120);
            lblEasy.Location = new Point(-84, -45);
            lblEasy.Name = "lblEasy";
            lblEasy.Size = new Size(80, 33);
            lblEasy.TabIndex = 9;
            lblEasy.Tag = "1";
            lblEasy.Text = "EASY";
            lblEasy.TextAlign = ContentAlignment.TopCenter;
            lblEasy.Click += lblEasy_Click;
            // 
            // lblBeginner
            // 
            lblBeginner.Anchor = AnchorStyles.None;
            lblBeginner.Font = new Font("Bahnschrift Condensed", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblBeginner.ForeColor = Color.FromArgb(80, 120, 120);
            lblBeginner.Location = new Point(-212, -45);
            lblBeginner.Name = "lblBeginner";
            lblBeginner.Size = new Size(122, 33);
            lblBeginner.TabIndex = 8;
            lblBeginner.Tag = "0";
            lblBeginner.Text = "BEGINNER";
            lblBeginner.TextAlign = ContentAlignment.TopCenter;
            lblBeginner.Click += lblBeginner_Click;
            // 
            // btnPlay
            // 
            btnPlay.Anchor = AnchorStyles.None;
            btnPlay.BackColor = Color.FromArgb(130, 160, 160);
            btnPlay.Font = new Font("Bahnschrift Condensed", 24F, FontStyle.Regular, GraphicsUnit.Point);
            btnPlay.Location = new Point(-16, 196);
            btnPlay.Margin = new Padding(3, 4, 3, 4);
            btnPlay.Name = "btnPlay";
            btnPlay.Size = new Size(195, 75);
            btnPlay.TabIndex = 1;
            btnPlay.Text = "PLAY";
            btnPlay.UseVisualStyleBackColor = false;
            btnPlay.Click += btnPlay_Click;
            // 
            // pbCanvasTitle
            // 
            pbCanvasTitle.Anchor = AnchorStyles.None;
            pbCanvasTitle.Location = new Point(-298, -175);
            pbCanvasTitle.Margin = new Padding(3, 4, 3, 4);
            pbCanvasTitle.Name = "pbCanvasTitle";
            pbCanvasTitle.Size = new Size(789, 499);
            pbCanvasTitle.TabIndex = 0;
            pbCanvasTitle.TabStop = false;
            pbCanvasTitle.Paint += pbCanvasTitle_Paint;
            // 
            // pnlGamePage
            // 
            pnlGamePage.BackColor = Color.FromArgb(30, 90, 60);
            pnlGamePage.Controls.Add(pbCanvasGameBoard);
            pnlGamePage.Controls.Add(pbCanvasBorder);
            pnlGamePage.Dock = DockStyle.Fill;
            pnlGamePage.Location = new Point(0, 0);
            pnlGamePage.Name = "pnlGamePage";
            pnlGamePage.Size = new Size(914, 600);
            pnlGamePage.TabIndex = 1;
            // 
            // pbCanvasGameBoard
            // 
            pbCanvasGameBoard.Location = new Point(185, 31);
            pbCanvasGameBoard.Name = "pbCanvasGameBoard";
            pbCanvasGameBoard.Size = new Size(540, 540);
            pbCanvasGameBoard.TabIndex = 0;
            pbCanvasGameBoard.TabStop = false;
            pbCanvasGameBoard.Paint += pbCanvasGameBoard_Paint;
            pbCanvasGameBoard.MouseDown += pbCanvasGameBoard_MouseDown;
            // 
            // pbCanvasBorder
            // 
            pbCanvasBorder.Location = new Point(175, 21);
            pbCanvasBorder.Name = "pbCanvasBorder";
            pbCanvasBorder.Size = new Size(560, 560);
            pbCanvasBorder.TabIndex = 1;
            pbCanvasBorder.TabStop = false;
            pbCanvasBorder.Paint += pbCanvasBorder_Paint;
            // 
            // Form1
            // 
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(914, 600);
            Controls.Add(pnlGamePage);
            Controls.Add(pnlTitle);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Minesweeper";
            Load += Form1_Load;
            pnlTitle.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pbCanvasTitle).EndInit();
            pnlGamePage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pbCanvasGameBoard).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbCanvasBorder).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlTitle;
        private PictureBox pbCanvasTitle;
        private Button btnPlay;
        private Label lblTitle;
        private Label lblBeginner;
        private Label lblEasy;
        private Label lblIntermediate;
        private Label lblExpert;
        private Label lblImpossible;
        private Panel pnlGamePage;
        private PictureBox pbCanvasGameBoard;
        private PictureBox pbCanvasBorder;
    }
}