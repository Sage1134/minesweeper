using System.Runtime.InteropServices;

namespace MinesweeperFinalProject
{
    public partial class Form1 : Form
    {
        // Define public variables
        public int iGameDifficulty;
        public int[] boardSizeArray = new int[5];
        public int[] mineCountArray = new int[5];
        public int[,] boardLayout;
        public string[,] cellStatusArray;
        public bool gameStarted = false;
        public Point startPaintArea = new Point(0, 0);

        // Get random number generator
        Random rng = new Random();
        public Form1()
        {
            InitializeComponent();

            // Define board sizes
            boardSizeArray[0] = 6;
            boardSizeArray[1] = 9;
            boardSizeArray[2] = 15;
            boardSizeArray[3] = 20;
            boardSizeArray[4] = 30;

            //Define mine counts
            mineCountArray[0] = 4;
            mineCountArray[1] = 12;
            mineCountArray[2] = 40;
            mineCountArray[3] = 85;
            mineCountArray[4] = 256;
        }


        private void selectDifficulty(Control label)
        {
            try
            {
                // Uncolour labels
                lblBeginner.ForeColor = Color.FromArgb(80, 120, 120);
                lblEasy.ForeColor = Color.FromArgb(80, 120, 120);
                lblIntermediate.ForeColor = Color.FromArgb(80, 120, 120);
                lblExpert.ForeColor = Color.FromArgb(80, 120, 120);
                lblImpossible.ForeColor = Color.FromArgb(80, 120, 120);

                // Colour correct label
                label.ForeColor = Color.FromArgb(60, 80, 80);

                // Set game difficulty
                iGameDifficulty = Convert.ToInt32(label.Tag);
            }
            catch
            {
                // Show error message
                MessageBox.Show("An error has occured. Please restart and try again");
            }
        }

        private void loadPage(Panel page)
        {
            try
            {
                // Loop through controls and hide all other panels
                foreach (Control control in Controls)
                {
                    if (control is Panel panel)
                    {
                        // Hide panels
                        control.Dock = DockStyle.None;
                        control.Hide();

                        //Show wanted panel
                        if (control == page)
                        {
                            control.Show();
                            control.Dock = DockStyle.Fill;
                            control.BringToFront();
                        }
                    }
                }
            }
            catch
            {
                // Show error message
                MessageBox.Show("An error has occured. Please restart and try again");
            }
        }
        private int[,] generateGameBoard(int gridSize, int minesWanted, int x, int y)
        {
            try
            {
                // Make initial board
                int[,] gameBoard = new int[gridSize, gridSize];

                // Initialize mine counter
                int iMineCounter = 0;

                // Initialize board with default values
                for (int i = 0; i < gridSize; i++)
                {
                    for (int j = 0; j < gridSize; j++)
                    {
                        gameBoard[i, j] = 0;
                    }
                }

                // Generate mines
                while (iMineCounter < minesWanted)
                {
                    int randomX = rng.Next(0, gridSize - 1);
                    int randomY = rng.Next(0, gridSize - 1);

                    if (gameBoard[randomX, randomY] != -1)
                    {
                        double iDistance = Math.Sqrt((randomX - x) * (randomX - x) + (randomY - y) * (randomY - y));
                        if (gridSize < 9)
                        {
                            if (iDistance > 2)
                            {
                                gameBoard[randomX, randomY] = -1;
                                iMineCounter++;
                            }
                        }
                        else if (iDistance > 2.25)
                        {
                            gameBoard[randomX, randomY] = -1;
                            iMineCounter++;
                        }
                    }
                }

                // Check neighbour cells for mine counts
                for (int i = 0; i < gridSize; i++)
                {
                    for (int j = 0; j < gridSize; j++)
                    {
                        if (gameBoard[i, j] == 0)
                        {
                            List<int> neighbourInfo = getNeighbourMines(gameBoard, gridSize, i, j);
                            int iMineCount = neighbourInfo.Count(item => item == -1);
                            gameBoard[i, j] = iMineCount;
                        }
                    }
                }

                // Return game board
                return gameBoard;
            }
            catch
            {
                // Show error message
                MessageBox.Show("An error has occured. Please restart and try again");
                return new int[0, 0];
            }
        }

        private List<int> getNeighbourMines(int[,] grid, int gridSize, int x, int y)
        {
            try
            {
                // Initialize neighbour list
                List<int> neighboursList = new List<int>();

                // Get adjacent cells information
                if (x - 1 >= 0)
                {
                    neighboursList.Add(grid[x - 1, y]);
                }
                if (x + 1 < gridSize)
                {
                    neighboursList.Add(grid[x + 1, y]);
                }
                if (y - 1 >= 0)
                {
                    neighboursList.Add(grid[x, y - 1]);
                }
                if (y + 1 < gridSize)
                {
                    neighboursList.Add(grid[x, y + 1]);
                }

                // Get corner cells information
                if (x - 1 >= 0 && y - 1 >= 0)
                {
                    neighboursList.Add(grid[x - 1, y - 1]);
                }
                if (x + 1 < gridSize && y - 1 >= 0)
                {
                    neighboursList.Add(grid[x + 1, y - 1]);
                }
                if (x - 1 > 0 && y + 1 < gridSize)
                {
                    neighboursList.Add(grid[x - 1, y + 1]);
                }
                if (x + 1 < gridSize && y + 1 < gridSize)
                {
                    neighboursList.Add(grid[x + 1, y + 1]);
                }

                // Return neighbour information
                return neighboursList;
            }
            catch
            {
                // Show error message
                MessageBox.Show("An error has occured. Please restart and try again");
                return new List<int> { 0 };
            }
        }

        private void ClearEmptyCells(int boardSize, int row, int col)
        {
            try
            {
                // Check if the current cell is within the game board bounds
                if (row < 0 || col < 0 || row >= boardSize || col >= boardSize)
                    return;

                // Return if cell is a mine
                if (boardLayout[row, col] == -1)
                {
                    return;
                }

                // Check if the current cell has already been cleared or is flagged
                if (cellStatusArray[row, col] != "Empty")
                    return;

                // Clear the current cell
                cellStatusArray[row, col] = "Cleared";
                paintCell(boardSize, row, col, pbCanvasGameBoard);

                // Return if cell has adjacent mines
                if (boardLayout[row, col] != 0)
                {
                    return;
                }

                // Recursively clear the adjacent cells
                int[] dx = { -1, -1, -1, 0, 0, 1, 1, 1 };
                int[] dy = { -1, 0, 1, 1, -1, -1, 0, 1 };

                for (int i = 0; i < dx.Length; i++)
                {
                    ClearEmptyCells(boardSize, row + dx[i], col + dy[i]);
                }
            }
            catch
            {
                // Show error message
                MessageBox.Show("An error has occured. Please restart and try again");
            }
        }

        private void paintCell(int boardSize, int row, int col, PictureBox canvas)
        {
            try
            {
                // Calculate top left point and create graphics + brushes
                int pixelsPerGrid = canvas.Width / boardSize;
                Point topLeft = new Point(row * pixelsPerGrid, col * pixelsPerGrid);
                Graphics g = canvas.CreateGraphics();
                SolidBrush myBrush = new SolidBrush(Color.Black);

                // Draw and fill cell
                Font myFont = new Font("Bahnschrift", pixelsPerGrid / 2);
                RectangleF rectangleBound = new RectangleF(topLeft.X, topLeft.Y + (pixelsPerGrid / 8), pixelsPerGrid, pixelsPerGrid);
                StringFormat stringFormat = new StringFormat();
                stringFormat.Alignment = StringAlignment.Center;

                if ((row + col) % 2 == 0)
                {
                    SolidBrush fillCellBrush = new SolidBrush(Color.FromArgb(210, 220, 140));
                    g.FillRectangle(fillCellBrush, topLeft.X, topLeft.Y, pixelsPerGrid, pixelsPerGrid);

                    // Dispose brush
                    fillCellBrush.Dispose();
                }
                else
                {
                    SolidBrush fillCellBrush = new SolidBrush(Color.FromArgb(220, 230, 150));
                    g.FillRectangle(fillCellBrush, topLeft.X, topLeft.Y, pixelsPerGrid, pixelsPerGrid);

                    // Dispose brush
                    fillCellBrush.Dispose();
                }
                g.DrawString(boardLayout[row, col].ToString(), myFont, myBrush, rectangleBound, stringFormat);

                // Dispose brush
                myBrush.Dispose();
            }
            catch
            {
                // Show error message
                MessageBox.Show("An error has occured. Please restart and try again");
            }
        }

        private void toggleFlagCell(int boardSize, int row, int col, PictureBox canvas)
        {
            try
            {
                // Calculate top left point and create graphics
                int pixelsPerGrid = canvas.Width / boardSize;
                Point topLeft = new Point(row * pixelsPerGrid, col * pixelsPerGrid);
                Graphics g = canvas.CreateGraphics();

                if (cellStatusArray[row, col] == "Empty")
                {
                    // Create brush and pen
                    SolidBrush myBrush = new SolidBrush(Color.Red);
                    Pen myPen = new Pen(Color.DarkRed, 4);

                    // Paint Flagged cell
                    g.DrawEllipse(myPen, topLeft.X + (pixelsPerGrid / 4), topLeft.Y + (pixelsPerGrid / 4), pixelsPerGrid / 2, pixelsPerGrid / 2);
                    g.FillEllipse(myBrush, topLeft.X + (pixelsPerGrid / 4), topLeft.Y + (pixelsPerGrid / 4), pixelsPerGrid / 2, pixelsPerGrid / 2);

                    // Dispose brushes
                    myBrush.Dispose();
                    myPen.Dispose();
                }
                else if (cellStatusArray[row, col] == "Flagged")
                {
                    // Create brush and pen
                    if ((row + col) % 2 == 0)
                    {
                        SolidBrush myBrush = new SolidBrush(Color.FromArgb(140, 220, 110));

                        // Clear flag on cell
                        g.FillRectangle(myBrush, topLeft.X, topLeft.Y, pixelsPerGrid, pixelsPerGrid);

                        // Dispose brush
                        myBrush.Dispose();
                    }
                    else
                    {
                        SolidBrush myBrush = new SolidBrush(Color.FromArgb(150, 240, 120));

                        // Clear flag on cell
                        g.FillRectangle(myBrush, topLeft.X, topLeft.Y, pixelsPerGrid, pixelsPerGrid);

                        // Dispose brush
                        myBrush.Dispose();
                    }
                }
            }
            catch
            {
                // Show error message
                MessageBox.Show("An error has occured. Please restart and try again");
            }
        }

        private void pbCanvasTitle_Paint(object sender, PaintEventArgs e)
        {
            try
            {
                // Draw title rectangle
                Graphics g = e.Graphics;
                Pen myPen = new Pen(Color.WhiteSmoke, 4);

                g.DrawRectangle(myPen, 0, 0, pbCanvasTitle.Width, pbCanvasTitle.Height);
            }
            catch
            {
                // Show error message
                MessageBox.Show("An error has occured. Please restart and try again");
            }
        }

        private void lblBeginner_Click(object sender, EventArgs e)
        {
            // Set difficulty
            selectDifficulty(lblBeginner);
        }

        private void lblEasy_Click(object sender, EventArgs e)
        {
            // Set difficulty
            selectDifficulty(lblEasy);
        }

        private void lblIntermediate_Click(object sender, EventArgs e)
        {
            // Set difficulty
            selectDifficulty(lblIntermediate);
        }

        private void lblExpert_Click(object sender, EventArgs e)
        {
            // Set difficulty
            selectDifficulty(lblExpert);
        }

        private void lblImpossible_Click(object sender, EventArgs e)
        {
            // Set difficulty
            selectDifficulty(lblImpossible);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Load title page
            loadPage(pnlTitle);

            // Set difficulty
            selectDifficulty(lblIntermediate);
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            // Load game page
            loadPage(pnlGamePage);

            pbCanvasGameBoard.Refresh();
        }

        private void pbCanvasGameBoard_Paint(object sender, PaintEventArgs e)
        {
            try
            {
                // Return if game has aleady started
                if (gameStarted)
                {
                    return;
                }

                // Gather board size
                int iHeight = pbCanvasGameBoard.Height;
                int iWidth = pbCanvasGameBoard.Width;

                // Calculate grid size
                int gridSize = iHeight / boardSizeArray[iGameDifficulty];

                // Define graphic components
                Graphics g = e.Graphics;

                // Generate blank grid

                Brush gridBrushDark = new SolidBrush(Color.FromArgb(140, 220, 110));
                Brush gridBrushLight = new SolidBrush(Color.FromArgb(150, 240, 120));

                for (int i = 0; i < boardSizeArray[iGameDifficulty]; i++)
                {
                    for (int j = 0; j < boardSizeArray[iGameDifficulty]; j++)
                    {
                        if ((j + i) % 2 == 0)
                        {
                            g.FillRectangle(gridBrushDark, i * gridSize, j * gridSize, gridSize, gridSize);
                        }
                        else
                        {
                            g.FillRectangle(gridBrushLight, i * gridSize, j * gridSize, gridSize, gridSize);
                        }
                    }
                }

                // Dispose brushes
                gridBrushDark.Dispose();
                gridBrushLight.Dispose();
            }
            catch
            {
                // Show error message
                MessageBox.Show("An error has occured. Please restart and try again");
            }
        }

        private void pbCanvasGameBoard_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                // Define and initialize variables
                int iBoardSize = boardSizeArray[iGameDifficulty];
                int pixelsPerGrid = pbCanvasGameBoard.Width / iBoardSize;
                int gridClickedX = e.X / pixelsPerGrid;
                int gridClickedY = e.Y / pixelsPerGrid;

                if (e.Button == MouseButtons.Left)
                {
                    // Check if game has started
                    if (gameStarted)
                    {
                        ClearEmptyCells(iBoardSize, gridClickedX, gridClickedY);
                    }
                    else
                    {
                        // Start game
                        gameStarted = true;

                        // Create game board
                        boardLayout = generateGameBoard(boardSizeArray[iGameDifficulty], mineCountArray[iGameDifficulty], gridClickedX, gridClickedY);

                        // Create and initialize cell status array
                        cellStatusArray = new string[iBoardSize, iBoardSize];

                        for (int i = 0; i < iBoardSize; i++)
                        {
                            for (int j = 0; j < iBoardSize; j++)
                            {
                                cellStatusArray[i, j] = "Empty";
                            }
                        }

                        ClearEmptyCells(iBoardSize, gridClickedX, gridClickedY);
                    }
                }
                else if (e.Button == MouseButtons.Right)
                {
                    // Check if game has started
                    if (gameStarted)
                    {
                        if (cellStatusArray[gridClickedX, gridClickedY] == "Empty")
                        {
                            // Paint cell
                            toggleFlagCell(iBoardSize, gridClickedX, gridClickedY, pbCanvasGameBoard);

                            // Update cellStatusArray
                            cellStatusArray[gridClickedX, gridClickedY] = "Flagged";
                        }
                        else if (cellStatusArray[gridClickedX, gridClickedY] == "Flagged")
                        {
                            // Unpaint cell
                            toggleFlagCell(iBoardSize, gridClickedX, gridClickedY, pbCanvasGameBoard);

                            //Update cellStatusArray
                            cellStatusArray[gridClickedX, gridClickedY] = "Empty";
                        }
                    }
                }
            }
            catch
            {
                // Show error message
                MessageBox.Show("An error has occured. Please restart and try again");
            }
        }

        private void pbCanvasBorder_Paint(object sender, PaintEventArgs e)
        {
            // Add border
            Pen borderPen = new Pen(Color.FromArgb(200, 255, 240), 20);
            Graphics g = e.Graphics;
            g.DrawRectangle(borderPen, 0, 0, 560, 560);

            // Dispose graphics and pen
            borderPen.Dispose();
        }
    }
}